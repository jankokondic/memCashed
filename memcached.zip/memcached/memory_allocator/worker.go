package memory_allocator

import (
	"io"
	"log"
	"time"
	"unsafe"

	"github.com/WatchJani/memCashed/memcached/constants"
	"github.com/WatchJani/memCashed/memcached/link_list"
	decoder "github.com/WatchJani/memCashed/memcached/parser"
)

const (
	StatusOK       byte = 1
	StatusNotFound byte = 2
	StatusExpired  byte = 3
	StatusError    byte = 4
)

var (
	ResponseInserted = []byte{StatusOK}
	ResponseDeleted  = []byte{StatusOK}
	ResponseNotFound = []byte{StatusNotFound}
	ResponseExpired  = []byte{StatusExpired}
	ResponseError    = []byte{StatusError}
)

func WriteStaticResponse(w io.Writer, response []byte) {
	if _, err := w.Write(response); err != nil {
		log.Println(err)
	}
}

func WriteValueResponse(w io.Writer, value []byte) {
	var header [5]byte

	header[0] = StatusOK
	decoder.LittleEndianEncode(header[1:5], uint32(len(value)))

	if _, err := w.Write(header[:]); err != nil {
		log.Println(err)
		return
	}

	if _, err := w.Write(value); err != nil {
		log.Println(err)
	}
}

func (s *SlabManager) Process(payload Transfer) {
	operation, keySize, ttl, bodySize := decoder.Decode(payload.payload)

	payload.operation = operation
	payload.keySize = int(keySize)
	payload.ttl = ttl
	payload.bodySize = int(bodySize)

	switch operation {
	case constants.SetOperation:
		s.SetOperationFn(payload)

	case constants.GetOperation:
		s.GetOperationFn(payload)

	case constants.DeleteOperation:
		s.DeleteOperationFn(payload)

	default:
		log.Println(constants.ErrOperationIsNotSupported)
		WriteStaticResponse(payload.conn, ResponseError)
	}
}

func (s *SlabManager) Worker() {
	for payload := range s.JobCh {
		s.Process(payload)
	}
}

func (s *SlabManager) SetOperationFn(payload Transfer) {
	bodyOffset := constants.HeaderSize + payload.keySize
	key := string(payload.payload[constants.HeaderSize:bodyOffset])

	if oldValueObject, isFound := s.store.Load(key); isFound {
		oldValue := oldValueObject.(Key)

		s.lru[oldValue.slabIndex].Delete(oldValue.pointer)

		memoryPointer := oldValue.pointer.GetPointer()
		s.slabs[oldValue.slabIndex].FreeMemory(memoryPointer)
	}

	node := s.lru[payload.index].Insert(
		link_list.NewValue(unsafe.Pointer(&payload.payload[0]), key),
	)

	s.store.Store(key, Key{
		field:     payload.payload[bodyOffset : bodyOffset+payload.bodySize],
		ttl:       TLLParser(payload.ttl),
		pointer:   node,
		slabIndex: payload.index,
	})

	WriteStaticResponse(payload.conn, ResponseInserted)
}

func (s *SlabManager) GetOperationFn(payload Transfer) {
	keyStart := constants.HeaderSize
	keyEnd := keyStart + payload.keySize

	key := string(payload.payload[keyStart:keyEnd])

	s.slabs[payload.index].FreeMemory(unsafe.Pointer(&payload.payload[0]))

	valueObject, isFound := s.store.Load(key)
	if !isFound {
		WriteStaticResponse(payload.conn, ResponseNotFound)
		return
	}

	value := valueObject.(Key)

	if !value.ttl.IsZero() && time.Now().After(value.ttl) {
		s.store.Delete(key)
		s.lru[value.slabIndex].Delete(value.pointer)

		memoryPointer := value.pointer.GetPointer()
		s.slabs[value.slabIndex].FreeMemory(memoryPointer)

		WriteStaticResponse(payload.conn, ResponseExpired)
		return
	}

	s.lru[value.slabIndex].Read(value.pointer)

	WriteValueResponse(payload.conn, value.field)
}

func (s *SlabManager) DeleteOperationFn(payload Transfer) {
	keyStart := constants.HeaderSize
	keyEnd := keyStart + payload.keySize

	key := string(payload.payload[keyStart:keyEnd])

	s.slabs[payload.index].FreeMemory(unsafe.Pointer(&payload.payload[0]))

	valueObject, isFound := s.store.Load(key)
	if !isFound {
		WriteStaticResponse(payload.conn, ResponseNotFound)
		return
	}

	value := valueObject.(Key)

	s.store.Delete(key)
	s.lru[value.slabIndex].Delete(value.pointer)

	memoryPointer := value.pointer.GetPointer()
	s.slabs[value.slabIndex].FreeMemory(memoryPointer)

	WriteStaticResponse(payload.conn, ResponseDeleted)
}
