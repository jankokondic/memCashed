package server

import (
	"io"
	"log"
	"net"
	"sync/atomic"
	"time"

	"github.com/WatchJani/memCashed/memcached/constants"
	"github.com/WatchJani/memCashed/memcached/internal/types"
	"github.com/WatchJani/memCashed/memcached/memory_allocator"
	decoder "github.com/WatchJani/memCashed/memcached/parser"
)

const (
	readBufferSize  = 256 * 1024
	writeBufferSize = 256 * 1024
	maxPendingSize  = 4 * 1024 * 1024
)

type Server struct {
	Add        string
	MaxConn    int64
	ActiveConn int64
	Manager    *memory_allocator.SlabManager
}

func New() *Server {
	config := types.LoadConfiguration()
	newAllocator := config.MemoryAllocator()

	return &Server{
		Add:     config.Port(),
		MaxConn: int64(config.MaxConnection()),
		Manager: memory_allocator.NewSlabManager(
			config.Slabs(newAllocator),
			config.NumberWorker(),
		),
	}
}

func (s *Server) Run() error {
	ls, err := net.Listen(constants.TCP, s.Add)
	if err != nil {
		return err
	}
	defer Close(ls, constants.InfoServerClose)

	for {
		conn, err := ls.Accept()
		if err != nil {
			log.Println(err)
			continue
		}

		if atomic.AddInt64(&s.ActiveConn, 1) > s.MaxConn {
			atomic.AddInt64(&s.ActiveConn, -1)
			_ = conn.Close()
			continue
		}

		configureTCP(conn)

		go s.HandleConn(conn)
	}
}

func configureTCP(conn net.Conn) {
	tcpConn, ok := conn.(*net.TCPConn)
	if !ok {
		return
	}

	_ = tcpConn.SetNoDelay(true)
	_ = tcpConn.SetKeepAlive(true)
	_ = tcpConn.SetKeepAlivePeriod(30 * time.Second)
	_ = tcpConn.SetReadBuffer(1024 * 1024)
	_ = tcpConn.SetWriteBuffer(1024 * 1024)
}

func (s *Server) decrease() {
	atomic.AddInt64(&s.ActiveConn, -1)
}

func Close(c io.Closer, msg string) {
	if err := c.Close(); err != nil {
		log.Println(err)
	}
}

func (s *Server) HandleConn(conn net.Conn) {
	defer func() {
		Close(conn, constants.InfoConnectionClose)
		s.decrease()
	}()

	var header [constants.BufferSizeTCP]byte

	for {
		_, err := io.ReadFull(conn, header[:])
		if err != nil {
			if err != io.EOF && err != io.ErrUnexpectedEOF {
				log.Println(err)
			}
			return
		}

		payloadSize := decoder.DecodeLength(header[:])

		slabBlock, index, err := s.Manager.GetSlab(payloadSize, nil)
		if err != nil {
			log.Println(err)

			_, _ = io.CopyN(io.Discard, conn, int64(payloadSize))
			continue
		}

		payload := slabBlock[:payloadSize]

		_, err = io.ReadFull(conn, payload)
		if err != nil {
			log.Println(err)
			return
		}

		s.Manager.Process(memory_allocator.NewTransfer(payload, index, conn))
	}
}
