module github.com/WatchJani/memCashed/memcached

go 1.22.0

require gopkg.in/yaml.v3 v3.0.1
